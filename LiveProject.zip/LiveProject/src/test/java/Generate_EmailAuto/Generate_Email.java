package Generate_EmailAuto;

import java.util.Date;

public class Generate_Email 
{
	public String generateEmail()
	{
	Date date = new Date();
	String dateString = date.toString();
	String noSpaceDateString = dateString.replaceAll("\\s", "").replaceAll("\\:", "");
	String emailWithTimeStamp = noSpaceDateString+"@gmail.com";
	return emailWithTimeStamp;
	}
	
	
}
 