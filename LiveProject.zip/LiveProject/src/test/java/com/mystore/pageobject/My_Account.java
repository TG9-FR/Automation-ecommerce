package com.mystore.pageobject;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class My_Account 
{
	WebDriver driver;
	
	public My_Account(WebDriver dri)
	{
		driver=dri;
		PageFactory.initElements(driver, this);
	}
	// TC 1 account creation
	@FindBy (id = "email_create")
	WebElement Email;
	
	@FindBy (xpath = "//span[normalize-space()='Create an account']")
	WebElement CreateAccount;
	
	//TC2 alredy resisteruser
	@FindBy (xpath = "//*[@id=\"email\"]")
	WebElement registerEmail;
	
	@FindBy (xpath = "//*[@id=\"passwd\"]")
	WebElement registerpassword;
	
	@FindBy (css = "button[id='SubmitLogin'] span")
	WebElement SignIn;
	
	@FindBy (xpath = "//*[@id=\"header\"]/div[2]/div/div/nav/div[2]/a")
	WebElement signOut;
	
	@FindBy (xpath = "//*[@id=\"search_query_top\"]")
	WebElement searchBox;
	
	@FindBy (xpath = "//*[@id=\"searchbox\"]/button")
	WebElement searchButton;
	
	@FindBy (xpath = "//*[@id=\"block_top_menu\"]/ul/li[1]/ul/li[1]/ul/li[1]/a")
	WebElement subMenuTshirt;
	
	public void EnterEmail(String mail)
	{
		Email.sendKeys(mail);
		
	}
	
	public void ClickCreateAccount()
	{
		CreateAccount.click();
	}
	
	public void EnterRegisterEmail(String mail)
	{
		registerEmail.sendKeys(mail);
		
	}
	
	public void EnterRegisterPassword(String mail)
	{
		registerpassword.sendKeys(mail);
		
	}
	
	public void clickSignIn()
	{
		SignIn.click();
	}
	
	public void clickSignOut()
	{
		signOut.click();
	}
	
	public void SearchBox(String text)
	{
		searchBox.sendKeys(text);
	}
	
	public void clickSearchButton()
	{
		searchButton.click();
	}
	
	public void SubMenuTshirt()
	{
		subMenuTshirt.click();
	}
}
