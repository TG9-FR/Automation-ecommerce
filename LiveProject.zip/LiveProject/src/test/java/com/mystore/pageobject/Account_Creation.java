package com.mystore.pageobject;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.Select;

public class Account_Creation 
{
WebDriver driver;
	
	public Account_Creation(WebDriver dri)
	{
		driver = dri;
		PageFactory.initElements(driver, this);
	}
	
	@FindBy (id = "id_gender1")
	WebElement gender;
	
	public void SelectGender()
	{
		gender.click();
	}
	
	@FindBy (xpath = "//*[@id=\"customer_firstname\"]")
	WebElement firstname;
	
	public void FirstName(String Fname)
	{
		firstname.sendKeys(Fname);
	}
	
	@FindBy (xpath = "//*[@id=\"customer_lastname\"]")
	WebElement lastname;
	
	public void LastName(String Lname)
	{
		lastname.sendKeys(Lname);
	}
	
	@FindBy (id = "email")
	WebElement email;
	
	public void EnterEmail(String Mail)
	{
		email.clear();
		email.sendKeys(Mail);
		
	}
	

	@FindBy (id = "passwd")
	WebElement password;
	
	public void EnterPassword(String Pass)
	{
		password.sendKeys(Pass);
	}
	
	@FindBy(xpath="//*[@id=\"days\"]")
	WebElement days;
	
	public void SelectDays(String text)
	{
		Select day=new Select(days);
				day.selectByValue(text);			
	}
	
	@FindBy (xpath = "//select[@id='months']")
	WebElement months;
	
	public void SelectMonths(String text2)
	{
		Select month = new Select(months);
				month.selectByValue(text2);
	}
	
	@FindBy (xpath = "//select[@id='years']")
	WebElement years;
	
	public void SelectYear(String text3)
	{
		Select year = new Select(years);
				year.selectByValue(text3);
	}
	
	@FindBy (xpath = "//input[@id='newsletter']")
	WebElement checkbox;
	
	public void ClickCheckBox()
	{
		checkbox.click();
	}
	
	@FindBy (xpath = "//span[normalize-space()='Register']")
	WebElement register;
	
	public void ClickRegister()
	{
		register.click();
	}

}
