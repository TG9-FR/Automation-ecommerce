package com.mystore.pageobject;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class validate_SearchResult 
{
	WebDriver driver;
	
	public validate_SearchResult(WebDriver dir)
	{
		driver = dir;
		PageFactory.initElements(driver, this);
	}
	
	@FindBy (xpath = "//*[@id=\"center_column\"]/h1/span[1]")
	WebElement validateSearch;
	
	public String Validate_Search()
	{
		String txt= validateSearch.getText();
		return txt;
	}

}
