package com.mystore.pageobject;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class VerifySignOut 
{
	WebDriver driver;
	
	public VerifySignOut(WebDriver dri)
	{
		driver = dri;
		PageFactory.initElements(driver, this); 
	}
	
	@FindBy (linkText = "Sign in")
	WebElement verifySignOut;
	
	
	
	public String verifysignout()
	{
		String txt = verifySignOut.getText();
		return txt;
	}
}
