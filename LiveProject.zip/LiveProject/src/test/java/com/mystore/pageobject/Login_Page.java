package com.mystore.pageobject;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
//With page object module method
public class Login_Page 
{
	//Create object for webdriver 
	WebDriver driver;
	//Create a constractor
	public Login_Page(WebDriver dri)
	{
		driver = dri;
		PageFactory.initElements(driver, this);	
	}
	//Identify elements by using page object factory
	//Method @findby
	@FindBy(linkText = "Sign in") 
	WebElement SignIn;
	
	//perform click action
	public void ClickSignIn()
	{
		SignIn.click();
	}
	
}
