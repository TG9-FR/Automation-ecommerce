package com.mystore.utilities;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;

import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class Read_Excel_File 
{
	public static FileInputStream inputStream;
	public static XSSFWorkbook workBook;
	public static XSSFSheet excelSheet;
	public static XSSFRow Row;
	public static XSSFCell Cell;
	
	public  static String getCellValue(String fileName, String sheetName, int rowNo, int cellNo) throws IOException
	{
		inputStream = new FileInputStream(fileName);
		workBook = new XSSFWorkbook(inputStream);
		excelSheet = workBook.getSheet(sheetName);
		Cell = workBook.getSheetAt(0).getRow(rowNo).getCell(cellNo);
		workBook.close();
		return Cell.getStringCellValue();
		
	}
	
	public static int getRewCount(String fileName, String sheetName) throws IOException
	{
		inputStream = new FileInputStream(fileName);
		workBook = new XSSFWorkbook(inputStream);
		excelSheet = workBook.getSheet(sheetName);
		int totalRow = excelSheet.getLastRowNum()+1;
		workBook.close();
		return totalRow;
		
	}
	
	public static int getColumnCount(String fileName, String sheetName) throws IOException
	{
		inputStream = new FileInputStream(fileName);
		workBook = new XSSFWorkbook(inputStream);
		excelSheet = workBook.getSheet(sheetName);
		int totalCell = excelSheet.getRow(0).getLastCellNum();
		workBook.close();
		return totalCell;
		
	}
}
