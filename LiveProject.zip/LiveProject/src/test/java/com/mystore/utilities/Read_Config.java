package com.mystore.utilities;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Properties;

@SuppressWarnings("unused")
public class Read_Config 
{
	Properties properties;
	String path = "C:\\Users\\SD\\eclipse-workspace\\LiveProject\\configuration\\config.properties";
	
	public Read_Config() throws IOException
	{
		properties = new Properties();
		FileInputStream read = new FileInputStream(path);
		
		properties.load(read);
	}
	
	public String getUrl()
	{
		String value = properties.getProperty("url");
		if(value!=null)
		{
			return value;
		}
		else
		{
			throw new RuntimeException("Url is not specified in config file");
		}
	}
	
	public String getBrowser()
	{
		String value = properties.getProperty("Browser");
		if(value!=null)
		{
			return value;
		}
		else
		{
			throw new RuntimeException("Browser is not specified in config file");
		}
	}
}
