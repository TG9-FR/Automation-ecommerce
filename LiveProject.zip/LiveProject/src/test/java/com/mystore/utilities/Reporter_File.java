package com.mystore.utilities;

import java.io.File;
import java.io.IOException;
import java.security.Timestamp;
import java.text.SimpleDateFormat;
import java.util.Date;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.testng.ITestContext;
import org.testng.ITestListener;
import org.testng.ITestResult;
import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;
import com.aventstack.extentreports.markuputils.ExtentColor;
import com.aventstack.extentreports.markuputils.MarkupHelper;
import com.aventstack.extentreports.reporter.ExtentSparkReporter;
import com.aventstack.extentreports.reporter.configuration.Theme;
import com.mystore.testcase.Base_Class;

public class Reporter_File extends Base_Class implements ITestListener
{

	ExtentSparkReporter htmlreport;
	ExtentReports reports;
	ExtentTest test;
	public void configurationReport()
	{
		String timestapm=new SimpleDateFormat("yy.MM.dd.hh.mm.ss").format(new Date());
		String reportName="MYStoreReport-"+timestapm+".html";
		htmlreport = new ExtentSparkReporter(System.getProperty("user.dir")+"//Reports//"+reportName);
		reports=new ExtentReports();
		 
		reports.attachReporter(htmlreport);
		reports.setSystemInfo("lenovo", "testPC1");
		reports.setSystemInfo("OS", "Windows");
		reports.setSystemInfo("user", "SD");
		reports.setSystemInfo("browser", "chrome");
		
		htmlreport.config().setDocumentTitle("Extent Report");
		htmlreport.config().setReportName("test report");
		htmlreport.config().setTheme(Theme.STANDARD);
	}
	
	@Override
	public void onStart(ITestContext result) 
	{
		configurationReport();
		System.out.println("on start method is invoke");
	}
	@Override
	public void onFinish(ITestContext result) 
	{
		reports.flush();
		System.out.println("on finish method is invoked");
	}
	@Override
	public void onTestStart(ITestResult result) 
	{
		System.out.println("Name of the test started :- "+result.getName());
		
	}
	@Override
	public void onTestSuccess(ITestResult result) 
	{
		System.out.println("Name of the test method success :- "+result.getName());
		test=reports.createTest(result.getName());
		test.log(Status.PASS, MarkupHelper.createLabel(result.getName()+"pass", ExtentColor.GREEN));
		test.pass(result.getThrowable());	
	}
	@Override
	public void onTestFailedButWithinSuccessPercentage(ITestResult result) 
	{	 		
	}
//	@Override
//	public void onTestFailure(ITestResult result) 
//	{
//		String testName = result.getName();
//		System.out.println("Name of the test method failed :- "+result.getName());
//		test=reports.createTest(result.getName());
//		test.log(Status.FAIL, MarkupHelper.createLabel("name of the failed test case:-"+result.getName(), ExtentColor.RED));
//		String screenshotpath=System.getProperty("user.dir")+"//ScreenShort//"+result.getName()+".png";
//		File screenshotfile= new File(screenshotpath);
//		if (screenshotfile.exists()) 
//		{
//			test.fail("captured screenshot is bellow :- "+test.addScreenCaptureFromPath(screenshotpath));  
//		}
//	}
	
	@Override
	public void onTestFailure(ITestResult result)
	{
		String testName = result.getName();
		System.out.println("Name of the test method failed :- "+result.getName());
		test=reports.createTest(result.getName());
		test.log(Status.FAIL, MarkupHelper.createLabel("name of the failed test case:-"+result.getName(), ExtentColor.RED));
		try {
		test.addScreenCaptureFromPath(CaptureScreenshot(testName, driver),testName);
		} catch (IOException e) {
		e.printStackTrace();
		}
	}

	@Override
	public void onTestSkipped(ITestResult result) 
	{
		System.out.println("Name of the test method skipped := "+result.getName());
		test=reports.createTest(result.getName());
		test.log(Status.SKIP, MarkupHelper.createLabel(result.getName()+"skip", ExtentColor.YELLOW));
		test.skip(result.getThrowable());	
	}
	
	
}
