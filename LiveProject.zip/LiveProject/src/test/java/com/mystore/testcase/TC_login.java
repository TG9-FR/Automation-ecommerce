package com.mystore.testcase;

import java.io.IOException;

import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import com.mystore.pageobject.Account_Creation;
import com.mystore.pageobject.Login_Page;
import com.mystore.pageobject.My_Account;
import com.mystore.pageobject.Register_Page;
import com.mystore.pageobject.VerifySignOut;
import com.mystore.pageobject.validate_SearchResult;

import Generate_EmailAuto.Generate_Email;

public class TC_login extends Base_Class 
{
	SoftAssert soft = new SoftAssert();
	
	@Test(priority = 1)
	public void VerifyRegistrationAndLogin() throws InterruptedException, IOException
	{
		Generate_Email ge = new Generate_Email();
		
		Login_Page pg = new Login_Page(driver);
		pg.ClickSignIn();
		logger.info("click on signin button...");
		
		My_Account acc = new My_Account(driver);
		acc.EnterEmail(ge.generateEmail());
		logger.info("Entered email...");
		acc.ClickCreateAccount();
		logger.info("Click on CreateAccount...");
		
		Account_Creation ac = new Account_Creation(driver); 
		ac.SelectGender();
		ac.FirstName("Suraj");
		ac.LastName("Dh");
		ac.EnterEmail(ge.generateEmail());
		
		ac.EnterPassword("12345");
		ac.SelectDays("19");
		ac.SelectMonths("2");
		ac.SelectYear("1900");
		ac.ClickCheckBox();
		ac.ClickRegister();
		logger.info("filled personal info");
		
		Register_Page page = new Register_Page(driver);
		String Actresult = page.VerifyUser();
		String Expresult = "Suraj Dhu";
		
		soft.assertEquals(Actresult, Expresult);
		CaptureScreenshot("VerifyRegistrationAndLogin", driver);
		
		Thread.sleep(1000);
		acc.clickSignOut();	
		soft.assertAll();
		
	}
	
	@Test(priority = 2)
	public void registration() throws IOException, InterruptedException
	{
		Login_Page pg = new Login_Page(driver);
		pg.ClickSignIn();
		logger.info("click on signin button...");
		
		
		My_Account acc = new My_Account(driver);
		acc.EnterRegisterEmail("sah@gmail.com");
		logger.info("Entered email");
		acc.EnterRegisterPassword("12345");
		logger.info("Entered Password");
		acc.clickSignIn();
		logger.info("Clicked SignIn"); 
		
		Register_Page page = new Register_Page(driver);
		String Actresult = page.VerifyUser();
		String expected="Daf dsf";
		
		soft.assertEquals(Actresult, expected);
		CaptureScreenshot("registration", driver);
//		if(Actresult.equals(expected))
//			{
//				System.out.println("Test passed");	
//				
//			}
//		else
//		{
//			
//			System.out.println("Test failed..");
//			CaptureScreenshot("registration",driver);
//			
//    	}
		
		Thread.sleep(1000);
		acc.clickSignOut();
		soft.assertAll();
		

		
	}	
	
		@Test(priority = 3)
		public void SearchProduct() throws IOException, InterruptedException
		{
			Login_Page pg = new Login_Page(driver);
			pg.ClickSignIn();
			logger.info("Clicked on Signin button....");
			
			My_Account acc = new My_Account(driver);
			acc.EnterRegisterEmail("sah@gmail.com");
			logger.info("Entered email...");
			acc.EnterRegisterPassword("12345");
			logger.info("Entered password...");
			acc.clickSignIn();
			logger.info("Clicked on signIn...");
			acc.SearchBox("t-shirts");
			logger.info("Entered text...");
			acc.clickSearchButton();
			logger.info("Clicked on search button...");
			
			validate_SearchResult valid = new validate_SearchResult(driver);
			String actresult = valid.Validate_Search().replaceAll("\"", "");
			String expresult = "T-SHIRTS";
			soft.assertEquals(actresult, expresult);
			CaptureScreenshot("SearchProduct", driver);
			
			Thread.sleep(1000);
			acc.clickSignOut();
			soft.assertAll();
		}
		
		@Test (priority = 4)
		public void verifySignOut() throws IOException, InterruptedException
		{
			Login_Page pg = new Login_Page(driver);
			pg.ClickSignIn();
			logger.info("click on signin button...");
			
			My_Account ac = new My_Account(driver);
			ac.EnterRegisterEmail("sah@gmail.com");
			logger.info("Entered email...");
			ac.EnterRegisterPassword("12345");
			logger.info("Entered password...");
			ac.clickSignIn();
			logger.info("Clicked on signIn...");
			ac.clickSignOut();
			logger.info("Clicked on signInOut...");
			
			VerifySignOut vso = new VerifySignOut(driver);
			String Actresult = vso.verifysignout();
			String Expresult = "Sign in";
			System.out.println(Actresult);
			
			soft.assertEquals(Actresult, Expresult);
			CaptureScreenshot("verifySignOut",driver);
			
			Thread.sleep(1000);
			soft.assertAll();
		}
		
	
	
}
